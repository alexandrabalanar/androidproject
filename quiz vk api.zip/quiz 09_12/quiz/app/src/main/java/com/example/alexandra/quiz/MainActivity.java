package com.example.alexandra.quiz;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.vk.sdk.util.VKUtil;

import java.sql.Array;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    final String TAG = "myLogs";
    ImageButton playButton;
    ImageButton achivementButton;
    ImageButton setingsButton;
    public int k=1;
    public MediaPlayer mySong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playButton=(ImageButton) findViewById(R.id.playButton);
        achivementButton=(ImageButton) findViewById(R.id.achivementButton);
        setingsButton=(ImageButton) findViewById(R.id.setingsButton);
        playButton.setOnClickListener(this);
        achivementButton.setOnClickListener(this);
        setingsButton.setOnClickListener(this);
        Log.d(TAG, "MainActivity OnCreate");
        //startService(new Intent(this, MyService.class));
     //   k=1;
       // Intent intent = new Intent(MainActivity.this, Settings.class);
    //    intent.putExtra("k", k);
        String[] fingerprints = VKUtil.getCertificateFingerprint(this, this.getPackageName());
        System.out.println(Arrays.asList(fingerprints));


    }



    @Override
    public void onUserLeaveHint() {


   //     super.onUserLeaveHint();

//        stopService(new Intent(this, MyService.class));

    }


    protected void onRestart()
    {
        super.onRestart();
        Log.d(TAG, "MainActivity OnRestart");


    }
    protected void onStart()
    {
        super.onStart();
        Log.d(TAG, "MainActivity OnStart");

    }
    protected void onResume()
    {

        super.onResume();
        Log.d(TAG, "MainActivity OnResume");


    }
    protected void onPause()
    {

        super.onPause();
        Log.d(TAG, "MainActivity OnPause");


    }
    protected void onStop()
    {

        super.onStop();
        Log.d(TAG, "MainActivity OnStop");



    }
    @Override
    public void onDestroy(){
        super.onDestroy();

    }

    @Override
    public void onClick(View v)
    {
        Intent intent;
        switch (v.getId())
        {
            case R.id.achivementButton:
                  intent = new Intent(this, RecordsActivity.class);
               startActivity(intent);
                break;
            case R.id.playButton:
                intent = new Intent(this, QuizActivity.class);
                startActivity(intent);
                break;
           case R.id.setingsButton:
                intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                break;

        }
    }
}
