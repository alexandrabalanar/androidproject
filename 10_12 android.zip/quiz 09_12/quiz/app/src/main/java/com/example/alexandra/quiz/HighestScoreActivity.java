package com.example.alexandra.quiz;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.alexandra.quiz.QuizActivity;
import com.example.alexandra.quiz.R;

public class HighestScoreActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_highest_score);
        Button HomeButton;
        TextView falsescore = (TextView) findViewById(R.id.falseScore);
        TextView txtScore = (TextView) findViewById(R.id.textScore);
        HomeButton=(Button) findViewById(R.id.homeButton);
        TextView txtHighScore = (TextView) findViewById(R.id.textHighScore);
        HomeButton.setOnClickListener(this);
        // receive the score from last activity by Intent
        Intent intent = getIntent();
        int score = intent.getIntExtra("score", 0);
        // display current score
        int fscore = intent.getIntExtra("fscore", 0);
        txtScore.setText("Your score: " + score);
        falsescore.setText("False answer: " + fscore);
        // use Shared preferences to save the best score
        SharedPreferences mypref = getPreferences(MODE_PRIVATE);
        int highscore = mypref.getInt("highscore",0);
        if(highscore>= score)
            txtHighScore.setText("High score: "+highscore);
        else
        {
            txtHighScore.setText("New highscore: "+score);
            SharedPreferences.Editor editor = mypref.edit();
            editor.putInt("highscore", score);
            editor.commit();
        }
    }

    public void onRepeatClick(View view) {
        Intent intent = new Intent(HighestScoreActivity.this, QuizActivity.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View v)
    {
        Intent intent;
        switch (v.getId())
        {
            case R.id.homeButton:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
        }
    }
}

